'use strict';

// =================================================================================
// App Configuration
// =================================================================================

const {OperationHelper} = require('apac');
var xml2js = require('xml2js');
var parser = new xml2js.Parser();

const opHelper = new OperationHelper({

    awsId:     'AKIAIQWXVVSOIXRWDBIQ',
    awsSecret: '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',
    assocId:   'theaedifex-21',
    locale :    "IN"
    
});

const {App} = require('jovo-framework');

const config = {
    logging: true,
};

const app = new App(config);


// =================================================================================
// App Logic
// =================================================================================

app.setHandler({
    'LAUNCH': function() {
        this.toIntent('HelloWorldIntent');
    },

    'HelloWorldIntent': function() {
        console.err('it works');
        this.ask('Hello World! What\'s your name?', 'Please tell me your name.');
    },

    'MyNameIsIntent': function(name) {
        this.tell('Hey ' + name.value + ', nice to meet you!');
    },

    'WhatIsTheCategoryIntent' : function(cat){
        //this.ask('Is this _' + cat.value +'_ the category?');
        
        opHelper.execute('ItemSearch', {
            'Keywords': cat.value,
            'SearchIndex':'All',
            'ResponseGroup': 'Images,ItemAttributes'
        }).then((response) => {
            //console.log("Results object: ", response.result);
            //this.ask('The Result is _' + response.responseBody +'_ ');
            var xml = response.responseBody;
            
            parser.parseString(xml, function (err, result) {
                
                //var mainOBJ = result.ItemSearchResponse.$;
                
                var Image1 = result.ItemSearchResponse.Items[0].Item[0].LargeImage[0].URL;//Item wala bit will change
                var Image1DetailsPage = result.ItemSearchResponse.Items[0].Item[0].DetailPageURL;
                var Image1DetailsTitle = result.ItemSearchResponse.Items[0].Item[0].ItemAttributes[0].Title;

                var Image2 = result.ItemSearchResponse.Items[0].Item[1].LargeImage[0].URL;//Item wala bit will change
                var Image2DetailsPage = result.ItemSearchResponse.Items[0].Item[1].DetailPageURL;
                var Image2DetailsTitle = result.ItemSearchResponse.Items[0].Item[1].ItemAttributes[0].Title;

                var Image3 = result.ItemSearchResponse.Items[0].Item[2].LargeImage[0].URL;//Item wala bit will change
                var Image3DetailsPage = result.ItemSearchResponse.Items[0].Item[2].DetailPageURL;
                var Image3DetailsTitle = result.ItemSearchResponse.Items[0].Item[2].ItemAttributes[0].Title;


                var Image4 = result.ItemSearchResponse.Items[0].Item[4].LargeImage[0].URL;//Item wala bit will change
                var Image4DetailsPage = result.ItemSearchResponse.Items[0].Item[4].DetailPageURL;
                var Image4DetailsTitle = result.ItemSearchResponse.Items[0].Item[4].ItemAttributes[0].Title;
                

                var Image5 = result.ItemSearchResponse.Items[0].Item[5].LargeImage[0].URL;//Item wala bit will change
                var Image5DetailsPage = result.ItemSearchResponse.Items[0].Item[5].DetailPageURL;
                var Image5DetailsTitle = result.ItemSearchResponse.Items[0].Item[5].ItemAttributes[0].Title;
                //console.log("$ op is",mainOBJ)
                //console.log("simple op is",secOBJ);
                console.log("first Image is , ",Image1[0]);
                console.log("first image title is",Image1DetailsTitle[0])
                console.log("second Image is , ",Image2[0]);
                console.log("first image title is",Image2DetailsTitle[0])
                console.log("third Image is , ",Image3[0]);
                console.log("first image title is",Image3DetailsTitle[0])
                console.log("fourth Image is , ",Image4[0]);
                console.log("first image title is",Image4DetailsTitle[0])
                console.log("fifth Image is , ",Image5[0]);
                console.log("first image title is",Image5DetailsTitle[0])


                /*for (var key in mainOBJ) {
                    console.log(key);
                }*/
                //

            });


            //console.log("Raw response body: ", response.responseBody);
            }).catch((err) => {
                console.error("Something went wrong! ", err);
            });
            

    }
});

module.exports.app = app;
